
<!-- Home page -->
<div class="home-page">
	<div class="row latest">
        
        <!-- 404 -->
        <div class="col-md-12">
            <fieldset>
                <legend>Not Found</legend>
                
                <div class="btn_align">
                    Sorry the page you were looking for could not be found
                </div>
            </fieldset>
        </div><!-- End 404 -->
	</div><!-- End inner-page -->
    
    <!-- Latest -->
	<?php $this->load->view('latest');?>
    <!-- End latest -->