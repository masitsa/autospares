<link href="<?php echo base_url()."assets/css/";?>dropzone.css" rel="stylesheet"/>
<script src="<?php echo base_url()."assets/js/";?>dropzone.js"></script>
<form action="/file-upload"
      class="dropzone"
      id="my-awesome-dropzone"></form>