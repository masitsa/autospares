<!DOCTYPE html>
<html>
  <head>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	 <title>Autospares</title>
  </head>
  <body style="background:url(<?php echo base_url()."assets/img/";?>website_under_construction1.png) center 100px #fff no-repeat; background-size:800px;">
  </body>
</html>