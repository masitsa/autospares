<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
	<link rel="stylesheet" href="<?php echo base_url();?>assets/css/font-awesome.min.css">
</head>

<body>
<button><i class="fa fa-shopping-cart"></i> fa-shopping-cart</button>
</body>
</html>