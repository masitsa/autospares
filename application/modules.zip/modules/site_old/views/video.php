		<!-- Latest -->
        <div class="latest">
        	<h1 class="home-title">How To Sell</h1>
            
            <div style="margin:0 auto; text-align:center;">
                <iframe class="latest2" src="//www.youtube.com/embed/L3ZLNKko9q4?rel=0" frameborder="0" allowfullscreen></iframe>
            </div>
        </div><!-- End latest -->