<?php
class Login extends MX_Controller {
	function __construct() 
	{
		redirect('admin');
  	}
	
	function index()
	{
		redirect('admin');
	}
}