	
		<title>Autospares :: <?php echo $title;?></title>
    	<!-- Basic Page Needs
		  ================================================== -->
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<meta name="description" content="Buy and sell vehicle spares online">
		<meta name="keywords" content="vehicle car spares spareparts parts">
		<meta name="author" content="Alvaro Masitsa">
		<!-- Mobile Specific Metas
		  ================================================== -->
		<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0">
		<meta name="format-detection" content="telephone=no">
        <!-- Favicon -->
        <link href="<?php echo base_url();?>assets/img/favicon.png" rel="shortcut icon" />
		<!-- CSS
		  ================================================== -->
		<link href="<?php echo base_url()."assets/themes/autostarts/";?>css/bootstrap.css" rel="stylesheet" type="text/css">
		<link href="<?php echo base_url()."assets/themes/autostarts/";?>css/bootstrap-theme.css" rel="stylesheet" type="text/css">
		<link href="<?php echo base_url()."assets/themes/autostarts/";?>css/style.css" rel="stylesheet" type="text/css">
		<link href="<?php echo base_url()."assets/themes/autostarts/";?>vendor/prettyphoto/css/prettyPhoto.css" rel="stylesheet" type="text/css">
		<link href="<?php echo base_url()."assets/themes/autostarts/";?>vendor/owl-carousel/css/owl.carousel.css" rel="stylesheet" type="text/css">
		<link href="<?php echo base_url()."assets/themes/autostarts/";?>vendor/owl-carousel/css/owl.theme.css" rel="stylesheet" type="text/css">
		<!--[if lte IE 9]><link rel="stylesheet" type="text/css" href="css/ie.css" media="screen" /><![endif]-->
		<link href="<?php echo base_url()."assets/themes/autostarts/";?>css/custom.css" rel="stylesheet" type="text/css"><!-- CUSTOM STYLESHEET FOR STYLING -->
		<!-- Color Style -->
		<link class="alt" href="<?php echo base_url()."assets/themes/autostarts/";?>colors/color2.css" rel="stylesheet" type="text/css">
		<!-- SCRIPTS
		  ================================================== -->
		<script src="<?php echo base_url()."assets/themes/autostarts/";?>js/modernizr.js"></script><!-- Modernizr -->
		<script src="<?php echo base_url()."assets/themes/autostarts/";?>js/jquery-2.0.0.min.js"></script> <!-- Jquery Library Call -->
		<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="<?php echo base_url()."assets/dist/";?>jquery.kyco.easyshare.min.js"></script>

<link href="//maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css" rel="stylesheet">
<link rel="stylesheet" href="<?php echo base_url()."assets/dist/";?>jquery.kyco.easyshare.css">